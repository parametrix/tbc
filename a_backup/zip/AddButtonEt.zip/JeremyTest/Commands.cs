﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;





namespace JeremyTest
{
        [TransactionAttribute(TransactionMode.Automatic)]
        [RegenerationAttribute(RegenerationOption.Manual)]
        public class Cmd_GBS_EnergySavingsPotential : IExternalCommand
        {
            public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
            {

                return Result.Succeeded;
            }
        }

}
