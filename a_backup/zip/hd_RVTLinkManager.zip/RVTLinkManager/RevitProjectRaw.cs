﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace RevitFileData
{
    class RevitProjectRaw
    {

        public ProjectData GetRevitBasicFileInfo(string pathToRevitFile)
        {

            var rawData = GetStreamData(pathToRevitFile);

            var rawString = System.Text.Encoding.Unicode.GetString(rawData);

            var fileInfoData = rawString.Split(new string[] { "\0", "\r\n", "਍" }, StringSplitOptions.RemoveEmptyEntries);
            ProjectData pd = new ProjectData();
            foreach (string raw in fileInfoData)
            {
                foreach (string search in SearchTerms())
                {
                    if (raw.StartsWith(search + ":"))
                    {
                        string[] array = raw.Split(new[] { ':' }, 2);

                        string prop = array[0];
                        string value = array.Count() > 1 ? array[1].Trim(): string.Empty;
                
                        if (prop == "Worksharing")
                        {
                            pd.IsWorkshared = value.StartsWith("Not") ? false : true;
                        }
                        else if (prop == "Username")
                        {
                            pd.UserName = value;
                        }
                        else if (prop == "Central Model Path")
                        {
                            pd.CentralPath = value;
                        }
                        else if (prop == "Revit Build")
                        {
                            pd.SavedInVersion = value;
                        }
                        else if (prop == "All Local Changes Saved To Central")
                        {
                            pd.AllLocalChangesSavedToCentral = value == "0" ? false : true;
                        }
                    }
                }
            }

            pd.IsCentral = pathToRevitFile == pd.CentralPath ? true : false;
            pd.IsLocal = !pd.IsCentral && pd.IsWorkshared;
            pd.IsCreatedLocal = false; // not sure what this is
            pd.LastSaved = File.GetLastWriteTime(pathToRevitFile);
            pd.FileName = Path.GetFileNameWithoutExtension(pathToRevitFile);
            return pd;

        }

        private static List<string> SearchTerms()
        {
            return new List<string>() { "Worksharing", "Username", "Central Model Path", "Revit Build", "Last Save Path", "All Local Changes Saved To Central" };
        }

        private static byte[] GetStreamData(string revitFileName)
        {
            if (!StructuredStorageUtils.IsFileStucturedStorage(
              revitFileName))
            {
                throw new NotSupportedException(
                  "File is not a structured storage file");
            }

            using (StructuredStorageRoot ssRoot =
                new StructuredStorageRoot(revitFileName))
            {
                if (!ssRoot.BaseRoot.StreamExists(StreamName))
                    throw new NotSupportedException(string.Format(
                      "File doesn't contain {0} stream", StreamName));

                StreamInfo imageStreamInfo =
                    ssRoot.BaseRoot.GetStreamInfo(StreamName);

                using (Stream stream = imageStreamInfo.GetStream(
                  FileMode.Open, FileAccess.Read))
                {
                    byte[] buffer = new byte[stream.Length];
                    stream.Read(buffer, 0, buffer.Length);
                    return buffer;
                }
            }
        }

        private const string StreamName = "BasicFileInfo";

    }

    public static class StructuredStorageUtils
    {
        [DllImport("ole32.dll")]
        static extern int StgIsStorageFile([MarshalAs(UnmanagedType.LPWStr)]string pwcsName);

        public static bool IsFileStucturedStorage(string fileName)
        {
            int res = StgIsStorageFile(fileName);

            if (res == 0)
                return true;

            if (res == 1)
                return false;

            throw new FileNotFoundException(
              "File not found", fileName);
        }
    }

    public class StructuredStorageException : Exception
    {
        public StructuredStorageException()
        {
        }

        public StructuredStorageException(string message) : base(message)
        {
        }

        public StructuredStorageException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }

    public class StructuredStorageRoot : IDisposable
    {
        StorageInfo _storageRoot;

        public StructuredStorageRoot(Stream stream)
        {
            try
            {
                _storageRoot
                  = (StorageInfo)InvokeStorageRootMethod(
                    null, "CreateOnStream", stream);
            }
            catch (Exception ex)
            {
                throw new StructuredStorageException(
                  "Cannot get StructuredStorageRoot", ex);
            }
        }

        public StructuredStorageRoot(string fileName)
        {
            try
            {
                _storageRoot
                  = (StorageInfo)InvokeStorageRootMethod(
                    null, "Open", fileName, FileMode.Open,
                    FileAccess.Read, FileShare.Read);
            }
            catch (Exception ex)
            {
                throw new StructuredStorageException(
                  "Cannot get StructuredStorageRoot", ex);
            }
        }

        private static object InvokeStorageRootMethod(
          StorageInfo storageRoot,
          string methodName,
          params object[] methodArgs)
        {
            Type storageRootType
              = typeof(StorageInfo).Assembly.GetType(
                "System.IO.Packaging.StorageRoot",
                true, false);

            object result = storageRootType.InvokeMember(
              methodName,
              BindingFlags.Static | BindingFlags.Instance
              | BindingFlags.Public | BindingFlags.NonPublic
              | BindingFlags.InvokeMethod,
              null, storageRoot, methodArgs);

            return result;
        }

        private void CloseStorageRoot()
        {
            InvokeStorageRootMethod(_storageRoot, "Close");
        }

        #region Implementation of IDisposable

        public void Dispose()
        {
            CloseStorageRoot();
        }

        #endregion

        public StorageInfo BaseRoot
        {
            get { return _storageRoot; }
        }

        //private void ControlledApplication_DocumentOpening( 
        //  object sender,
        //  DocumentOpeningEventArgs e )
        //{
        //  FileInfo revitFileToUpgrade 
        //    = new FileInfo( e.PathName );

        //  Regex buildInfoRegex = new Regex(
        //    @"Revit\sArchitecture\s(?<Year>\d{4})\s"
        //    +@"\(Build:\s(?<Build>\w*)\((<Processor>\w{3})\)\)" );

        //  using( StreamReader streamReader =
        //    new StreamReader( e.PathName, Encoding.Unicode ) )
        //  {
        //    string fileContents = streamReader.ReadToEnd();

        //    Match buildInfo = buildInfoRegex.Match( fileContents );
        //    string year = buildInfo.Groups["Year"].Value;
        //    string build = buildInfo.Groups["Build"].Value;
        //    string processor = buildInfo.Groups["Processor"].Value;
        //  }
        //}

    }


}
